# Admin login details

To log in as an admin, use the following credentials:

- **Name:** Admin
-**Email:** Admin@mail.com
- **Password:** Admin@mail.com
