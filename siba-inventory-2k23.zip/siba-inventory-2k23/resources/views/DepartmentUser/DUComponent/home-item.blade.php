<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
      <div class="authentication-inner">
        <div class="card">
          <h5 class="card-header"></h5>
          <div class="card-body">
            <div class="row">
              <!-- Left side -->
              <div class="col-md-6">
                <!-- Your first input field -->
                <div class="tile1">
                    {{-- <img src="your_image_url.jpg" alt="Tile Image"> --}}
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
                <br><br><br>
                <div class="tile2">
                    {{-- <img src="your_image_url.jpg" alt="Tile Image"> --}}
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
              </div>

              <!-- Right side -->
              <div class="col-md-6">
                <!-- Your third input field -->
                <div class="tile3">
                    {{-- <img src="your_image_url.jpg" alt="Tile Image"> --}}
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
                <br><br><br>
                <div class="tile4">
                    {{-- <img src="your_image_url.jpg" alt="Tile Image"> --}}
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div

