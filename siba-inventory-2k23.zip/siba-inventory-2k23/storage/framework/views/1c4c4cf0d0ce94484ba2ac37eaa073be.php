<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
      <div class="authentication-inner">
        <div class="card">
          <h5 class="card-header"></h5>
          <div class="card-body">
            <div class="row">
              <!-- Left side -->
              <div class="col-md-6">
                <!-- Your first input field -->
                <div class="tile1">
                    
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
                <br><br><br>
                <div class="tile2">
                    
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
              </div>

              <!-- Right side -->
              <div class="col-md-6">
                <!-- Your third input field -->
                <div class="tile3">
                    
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
                <br><br><br>
                <div class="tile4">
                    
                    <h3>Your Title</h3>
                    <p>Your description goes here. This is a simple tile example.</p>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div

<?php /**PATH C:\Users\hasit\OneDrive\Documents\testing\Inventory-2k23\siba-inventory-2k23\resources\views/DepartmentUser/DUComponent/home-item.blade.php ENDPATH**/ ?>