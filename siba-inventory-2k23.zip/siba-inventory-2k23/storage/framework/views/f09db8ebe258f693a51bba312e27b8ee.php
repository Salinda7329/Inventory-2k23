<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
            <div class="card">
                <h5 class="card-header">View Return Items</h5>
                <br><br>
                <div class="card-body">
                    <div class="row">
                        <!-- Left side -->
                        <div class="col-md-6">

                        </div>
                        <!-- Right side -->
                        <div class="col-md-6">
            </div>

            <table id="example" class="hover" style="width:100%">
                <thead>
                    <tr>
                        <th>Return Date</th>
                        <th>Time</th>
                        <th>Item name</th>
                        <th>Item code</th>
                        <th>Return by</th>
                        <th>Departmant</th>
                        <th>Catagory Name</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td><?php echo $__env->make('storeManager.SMcomponent.accept-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('storeManager.SMcomponent.cancel-button-modal-request-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>

                    </tr>
                    <tr>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td>************</td>
                        <td><?php echo $__env->make('storeManager.SMcomponent.accept-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('storeManager.SMcomponent.cancel-button-modal-request-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                    </tr>


            </table>
                <script>
                    $(document).ready( function () {
                        $('#example').DataTable();
                    });
                </script>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\hasit\OneDrive\Documents\testing\Inventory-2k23\siba-inventory-2k23\resources\views/storeManager/SMcomponent/view-return-items.blade.php ENDPATH**/ ?>